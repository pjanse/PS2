import React, { Component } from "react";
import Card from "./Components/Card";

import "./App.css";

class App extends Component {
  constructor(props) {
    super(props);
    this.mackeyClick = this.mackeyClick.bind(this);
    this.state = {isMackey: false};
  }
  
  state = {
    isMackey: false,
  }

  mackeyClick = () =>{
    const isMackey = this.state.isMackey;
    if(!isMackey){
      this.setState({isMackey:true});
    }else{
      this.setState({isMackey:false});
    }
  }

  hideCards = () =>{
    var x = document.getElementById("users");

    if (x.style.display === "none"){
      x.style.display = "block";
    }else{
      x.style.display = "none";
    }
  };
  
  render(){
    const isMackey = this.state.isMackey;
    return (
      <div className="userApp" id = "userA">
        <div className="cards" id = "users">
          <Card mackey = {isMackey}/>
          <Card mackey = {isMackey}/>
          <Card mackey = {isMackey}/>
         </div>
        <button onClick={() => this.mackeyClick()}>Mackey</button>       
        <button onClick={() => this.hideCards()}>Display</button>
      </div>
  );
  }
}

export default App;
